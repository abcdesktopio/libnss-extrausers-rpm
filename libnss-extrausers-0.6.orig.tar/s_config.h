#define USERSFILE "/var/lib/extrausers/passwd"
#define SHADOWFILE "/var/lib/extrausers/shadow"
#define GROUPSFILE "/var/lib/extrausers/group"
#define MINUID 500
#define MINGID 500
#define USERSGID 100
